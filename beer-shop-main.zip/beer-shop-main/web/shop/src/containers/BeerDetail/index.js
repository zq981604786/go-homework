import React from "react";

export default function BeerDetail(props) {
    return <div>hi</div>;
}