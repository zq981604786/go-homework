package generate

//go:generate kratos proto client .
